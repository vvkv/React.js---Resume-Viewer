These are the files that go along with this lecture

The node_modules folder does not exist. To create it, run
npm install


To start the app, run
npm start